﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Score_File
{
    public partial class Form1 : Form
    {
        // Declare variables
        int count, total, score;
        double average;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        private void readButton_Click(object sender, EventArgs e)
        {
            
            StreamReader inputFile;

            try // Catch file system and parse errors.
            {
                inputFile = File.OpenText("Scores.txt");

                // Read all scores from file
                count = 0;
                total = 0;
                while (!inputFile.EndOfStream)
                {
                    // Read on line from file
                    score = int.Parse(inputFile.ReadLine());

                    count++; // Increment
                    total += score; // Running total
                }
                // Close the file
                inputFile.Close();

                // Calculate and display
                average = (double)total / count;
                countLabel.Text = count.ToString();
                totalLabel.Text = total.ToString();
                averageLabel.Text = average.ToString("n1");
            }
            catch (Exception ex)
            {
                // Display error message
                MessageBox.Show("Error reading file: " + ex.Message);
            }
        }

        private void openFileButton_Click(object sender, EventArgs e)
        {
            StreamReader inputFile;

            try // Catch file system and parse errors.
            {
                // Show the OpenFileDialog
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    inputFile = File.OpenText(openFileDialog.FileName);

                    // Read all scores from file
                    count = 0;
                    total = 0;
                    while (!inputFile.EndOfStream)
                    {
                        // Read on line from file
                        score = int.Parse(inputFile.ReadLine());

                        count++; // Increment
                        total += score; // Running total
                    }
                    // Close the file
                    inputFile.Close();

                    // Calculate and display
                    average = (double)total / count;
                    countLabel.Text = count.ToString();
                    totalLabel.Text = total.ToString();
                    averageLabel.Text = average.ToString("n1");
                }
                else
                {
                    MessageBox.Show("Error selecting file name.");
                } // End OpenFileDialog
            } // End Try
            catch (Exception ex)
            {
                // Display error message
                MessageBox.Show("Error reading file: " + ex.Message);
            }
        }

        private void saveFileButton_Click(object sender, EventArgs e)
        {
            // Catch file system exceptions
            try
            {
                StreamWriter resultFile;
                // Show Save File Dialog
                if (resultFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // Open File
                    resultFile = File.CreateText(resultFileDialog.FileName);
                    // Write results
                    resultFile.WriteLine(count.ToString());
                    resultFile.WriteLine(total.ToString());
                    resultFile.WriteLine(average.ToString("n1"));
                    // Close file
                    resultFile.Close();
                }
                else
                {
                    MessageBox.Show("Error selecting file name.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error writing file: " + ex.Message);
            }
        }
    }
}
