﻿namespace Method_Homework
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.part1Button = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.part2Button = new System.Windows.Forms.Button();
            this.part3Button = new System.Windows.Forms.Button();
            this.part4Button = new System.Windows.Forms.Button();
            this.part5Button = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.part2TextBox = new System.Windows.Forms.TextBox();
            this.part2Label = new System.Windows.Forms.Label();
            this.part3TextBox = new System.Windows.Forms.TextBox();
            this.part3Label = new System.Windows.Forms.Label();
            this.part4TextBox = new System.Windows.Forms.TextBox();
            this.part5Label = new System.Windows.Forms.Label();
            this.part5TextBox = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.part1Button);
            this.groupBox1.Location = new System.Drawing.Point(18, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(375, 62);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Part 1: Void Method with No Parameters";
            // 
            // part1Button
            // 
            this.part1Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part1Button.Location = new System.Drawing.Point(9, 23);
            this.part1Button.Margin = new System.Windows.Forms.Padding(4);
            this.part1Button.Name = "part1Button";
            this.part1Button.Size = new System.Drawing.Size(357, 28);
            this.part1Button.TabIndex = 0;
            this.part1Button.Text = "Display MessageBox";
            this.part1Button.UseVisualStyleBackColor = true;
            this.part1Button.Click += new System.EventHandler(this.part1Button_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.part2Button);
            this.groupBox2.Location = new System.Drawing.Point(18, 84);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(375, 62);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Part 2: Void Method with One Parameter";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.part3Label);
            this.groupBox3.Controls.Add(this.part3TextBox);
            this.groupBox3.Controls.Add(this.part3Button);
            this.groupBox3.Location = new System.Drawing.Point(18, 177);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(375, 85);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Part 3: Void Method with Output Parameter";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.part4TextBox);
            this.groupBox4.Controls.Add(this.part4Button);
            this.groupBox4.Location = new System.Drawing.Point(18, 270);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(375, 60);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Part 4: Method with Return Value";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.part5TextBox);
            this.groupBox5.Controls.Add(this.part5Label);
            this.groupBox5.Controls.Add(this.part5Button);
            this.groupBox5.Location = new System.Drawing.Point(18, 338);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(375, 87);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Part 5: Method with Reference Parameter";
            // 
            // part2Button
            // 
            this.part2Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part2Button.Location = new System.Drawing.Point(9, 23);
            this.part2Button.Margin = new System.Windows.Forms.Padding(4);
            this.part2Button.Name = "part2Button";
            this.part2Button.Size = new System.Drawing.Size(357, 28);
            this.part2Button.TabIndex = 1;
            this.part2Button.Text = "Display MessageBox";
            this.part2Button.UseVisualStyleBackColor = true;
            this.part2Button.Click += new System.EventHandler(this.part2Button_Click);
            // 
            // part3Button
            // 
            this.part3Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part3Button.Location = new System.Drawing.Point(151, 23);
            this.part3Button.Margin = new System.Windows.Forms.Padding(4);
            this.part3Button.Name = "part3Button";
            this.part3Button.Size = new System.Drawing.Size(215, 28);
            this.part3Button.TabIndex = 1;
            this.part3Button.Text = "Enter word and display message.";
            this.part3Button.UseVisualStyleBackColor = true;
            this.part3Button.Click += new System.EventHandler(this.part3Button_Click);
            // 
            // part4Button
            // 
            this.part4Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part4Button.Location = new System.Drawing.Point(151, 23);
            this.part4Button.Margin = new System.Windows.Forms.Padding(4);
            this.part4Button.Name = "part4Button";
            this.part4Button.Size = new System.Drawing.Size(215, 28);
            this.part4Button.TabIndex = 1;
            this.part4Button.Text = "Enter word and display message.";
            this.part4Button.UseVisualStyleBackColor = true;
            this.part4Button.Click += new System.EventHandler(this.part4Button_Click);
            // 
            // part5Button
            // 
            this.part5Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part5Button.Location = new System.Drawing.Point(151, 23);
            this.part5Button.Margin = new System.Windows.Forms.Padding(4);
            this.part5Button.Name = "part5Button";
            this.part5Button.Size = new System.Drawing.Size(215, 28);
            this.part5Button.TabIndex = 1;
            this.part5Button.Text = "Enter word and display message.";
            this.part5Button.UseVisualStyleBackColor = true;
            this.part5Button.Click += new System.EventHandler(this.part5Button_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.part2Label);
            this.groupBox9.Controls.Add(this.part2TextBox);
            this.groupBox9.Controls.Add(this.button4);
            this.groupBox9.Location = new System.Drawing.Point(18, 84);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox9.Size = new System.Drawing.Size(375, 85);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Part 2: Void Method with One Parameter";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(151, 23);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(215, 28);
            this.button4.TabIndex = 1;
            this.button4.Text = "Enter word and display message.";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.part2Button_Click);
            // 
            // part2TextBox
            // 
            this.part2TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part2TextBox.Location = new System.Drawing.Point(7, 26);
            this.part2TextBox.Name = "part2TextBox";
            this.part2TextBox.Size = new System.Drawing.Size(137, 22);
            this.part2TextBox.TabIndex = 2;
            // 
            // part2Label
            // 
            this.part2Label.BackColor = System.Drawing.Color.SteelBlue;
            this.part2Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.part2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part2Label.ForeColor = System.Drawing.Color.AliceBlue;
            this.part2Label.Location = new System.Drawing.Point(7, 55);
            this.part2Label.Name = "part2Label";
            this.part2Label.Size = new System.Drawing.Size(359, 22);
            this.part2Label.TabIndex = 3;
            this.part2Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // part3TextBox
            // 
            this.part3TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part3TextBox.Location = new System.Drawing.Point(7, 26);
            this.part3TextBox.Name = "part3TextBox";
            this.part3TextBox.Size = new System.Drawing.Size(137, 22);
            this.part3TextBox.TabIndex = 3;
            // 
            // part3Label
            // 
            this.part3Label.BackColor = System.Drawing.Color.Crimson;
            this.part3Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.part3Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part3Label.ForeColor = System.Drawing.Color.Pink;
            this.part3Label.Location = new System.Drawing.Point(9, 55);
            this.part3Label.Name = "part3Label";
            this.part3Label.Size = new System.Drawing.Size(359, 22);
            this.part3Label.TabIndex = 4;
            this.part3Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // part4TextBox
            // 
            this.part4TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part4TextBox.Location = new System.Drawing.Point(7, 26);
            this.part4TextBox.Name = "part4TextBox";
            this.part4TextBox.Size = new System.Drawing.Size(137, 22);
            this.part4TextBox.TabIndex = 4;
            // 
            // part5Label
            // 
            this.part5Label.BackColor = System.Drawing.Color.Purple;
            this.part5Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.part5Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part5Label.ForeColor = System.Drawing.Color.Thistle;
            this.part5Label.Location = new System.Drawing.Point(7, 55);
            this.part5Label.Name = "part5Label";
            this.part5Label.Size = new System.Drawing.Size(359, 22);
            this.part5Label.TabIndex = 6;
            this.part5Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // part5TextBox
            // 
            this.part5TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.part5TextBox.Location = new System.Drawing.Point(7, 26);
            this.part5TextBox.Name = "part5TextBox";
            this.part5TextBox.Size = new System.Drawing.Size(137, 22);
            this.part5TextBox.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(411, 436);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Method Homework";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button part1Button;
        private System.Windows.Forms.Button part2Button;
        private System.Windows.Forms.Button part3Button;
        private System.Windows.Forms.Button part4Button;
        private System.Windows.Forms.Button part5Button;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox part2TextBox;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label part2Label;
        private System.Windows.Forms.TextBox part3TextBox;
        private System.Windows.Forms.Label part3Label;
        private System.Windows.Forms.TextBox part4TextBox;
        private System.Windows.Forms.Label part5Label;
        private System.Windows.Forms.TextBox part5TextBox;
    }
}

