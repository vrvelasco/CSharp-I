﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fish_Food
{
    public partial class Form1 : Form
    {
        struct Fish // Declare fish structure
        {
            public string name, habitat, food;
        }

        //Declare and create list of fish
        List<Fish> fishList = new List<Fish>();

        public Form1()
        {
            InitializeComponent();
        }

        // Enter Fish Button Handler
        private void enterFishButton_Click(object sender, EventArgs e)
        {
            // Validate fish, habitat, and food
            if (fishTextBox.Text.Length > 0 && habitatTextBox.Text.Length > 0 && foodTextBox.Text.Length > 0)
            {
                // Create struct to hold data
                Fish fish = new Fish();
                fish.name = fishTextBox.Text;
                fish.habitat = habitatTextBox.Text;
                fish.food = foodTextBox.Text;

                // Add struct to List
                fishList.Add(fish);

                // Display the fish on the form
                fishListBox.Items.Add(fish.name + "\t" + fish.habitat + "\t" + fish.food);
            }
            else
            {
                MessageBox.Show("Please enter fish, habitat, and food.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        // Search Fish Button Handler
        private void searchFishButton_Click(object sender, EventArgs e)
        {
            // Validate search-fish
            if (searchFishTextBox.Text.Length > 0)
            {
                string searchFish = searchFishTextBox.Text;

                // Search for fish in list
                bool found = false;

                foreach (Fish fish in fishList)
                {
                    if (fish.name==searchFish)
                    {
                        // Display data for found fish
                        searchResultLabel.Text = fish.name + " lives in " + fish.habitat + " and eats " + fish.food;
                        found = true;
                    }
                }

                if(!found)
                {
                    searchResultLabel.Text = searchFish + " not found.";
                }
            }
            else
            {
                MessageBox.Show("Please enter fish to search for.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

    }
}
